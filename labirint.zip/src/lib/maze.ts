export type Dir = "top" | "right" | "bottom" | "left";

export interface Cell {
  top: boolean;
  right: boolean;
  bottom: boolean;
  left: boolean;
}

export type Grid = Cell[][];

const DX: Record<Dir, number> = { top: 0, right: 1, bottom: 0, left: -1 };
const DY: Record<Dir, number> = { top: -1, right: 0, bottom: 1, left: 0 };
const OPPOSITE: Record<Dir, Dir> = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right",
};

/** Generates a perfect maze using recursive backtracking (DFS). */
export function generateMaze(size: number, loopChance = 0): Grid {
  const grid: Grid = Array.from({ length: size }, () =>
    Array.from({ length: size }, () => ({
      top: true,
      right: true,
      bottom: true,
      left: true,
    })),
  );
  const visited = Array.from({ length: size }, () => Array(size).fill(false));
  const stack: [number, number][] = [[0, 0]];
  visited[0][0] = true;

  const dirs: Dir[] = ["top", "right", "bottom", "left"];

  while (stack.length) {
    const [r, c] = stack[stack.length - 1];
    const options: { dir: Dir; r: number; c: number }[] = [];
    for (const dir of dirs) {
      const nr = r + DY[dir];
      const nc = c + DX[dir];
      if (nr >= 0 && nr < size && nc >= 0 && nc < size && !visited[nr][nc]) {
        options.push({ dir, r: nr, c: nc });
      }
    }
    if (options.length === 0) {
      stack.pop();
      continue;
    }
    const pick = options[Math.floor(Math.random() * options.length)];
    grid[r][c][pick.dir] = false;
    grid[pick.r][pick.c][OPPOSITE[pick.dir]] = false;
    visited[pick.r][pick.c] = true;
    stack.push([pick.r, pick.c]);
  }

  // Optionally knock down a few extra walls to create loops / alt paths
  if (loopChance > 0) {
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        for (const dir of dirs) {
          if (Math.random() < loopChance && grid[r][c][dir]) {
            const nr = r + DY[dir];
            const nc = c + DX[dir];
            if (nr >= 0 && nr < size && nc >= 0 && nc < size) {
              grid[r][c][dir] = false;
              grid[nr][nc][OPPOSITE[dir]] = false;
            }
          }
        }
      }
    }
  }

  return grid;
}

export function canMove(grid: Grid, r: number, c: number, dir: Dir): boolean {
  if (!grid[r] || !grid[r][c]) return false;
  if (grid[r][c][dir]) return false;
  const nr = r + DY[dir];
  const nc = c + DX[dir];
  return nr >= 0 && nr < grid.length && nc >= 0 && nc < grid.length;
}

export function stepTo(r: number, c: number, dir: Dir): [number, number] {
  return [r + DY[dir], c + DX[dir]];
}

/** BFS to find the next best direction from start towards goal. */
export function nextHintDirection(
  grid: Grid,
  start: { r: number; c: number },
  goal: { r: number; c: number },
): Dir | null {
  const size = grid.length;
  const visited = Array.from({ length: size }, () => Array(size).fill(false));
  const prev: (null | { r: number; c: number; dir: Dir })[][] = Array.from(
    { length: size },
    () => Array(size).fill(null),
  );
  const queue: [number, number][] = [[start.r, start.c]];
  visited[start.r][start.c] = true;
  const dirs: Dir[] = ["top", "right", "bottom", "left"];

  while (queue.length) {
    const [r, c] = queue.shift()!;
    if (r === goal.r && c === goal.c) break;
    for (const dir of dirs) {
      if (!canMove(grid, r, c, dir)) continue;
      const [nr, nc] = stepTo(r, c, dir);
      if (!visited[nr][nc]) {
        visited[nr][nc] = true;
        prev[nr][nc] = { r, c, dir };
        queue.push([nr, nc]);
      }
    }
  }

  if (!visited[goal.r][goal.c]) return null;

  // Walk back from goal to start to find first move
  let cur = { r: goal.r, c: goal.c };
  let firstDir: Dir | null = null;
  while (prev[cur.r][cur.c]) {
    const p = prev[cur.r][cur.c]!;
    firstDir = p.dir;
    cur = { r: p.r, c: p.c };
  }
  return firstDir;
}

/** Returns the grid size for a given level. */
export function sizeForLevel(level: number): number {
  return Math.min(4 + Math.floor((level - 1) / 2), 9);
}

/** Returns memorize time (ms) for a given level. */
export function memorizeTimeForLevel(level: number): number {
  const base = 6000 - (level - 1) * 350;
  return Math.max(2000, base);
}
