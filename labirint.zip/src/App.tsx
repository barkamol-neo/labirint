import { useCallback, useEffect, useRef, useState } from "react";
import {
  Menu,
  Heart,
  Timer,
  Trophy,
  Eye,
  Lightbulb,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  X,
  RotateCcw,
  Flag,
  Sparkles,
} from "lucide-react";
import {
  generateMaze,
  canMove,
  stepTo,
  nextHintDirection,
  sizeForLevel,
  memorizeTimeForLevel,
  type Dir,
  type Grid,
} from "./lib/maze";

type Phase = "memorize" | "play" | "won" | "lost";

function formatTime(totalSec: number) {
  const m = Math.floor(totalSec / 60)
    .toString()
    .padStart(2, "0");
  const s = Math.floor(totalSec % 60)
    .toString()
    .padStart(2, "0");
  return `${m}:${s}`;
}

export default function App() {
  const [started, setStarted] = useState(false);
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState<number>(() => {
    const v = Number(localStorage.getItem("maze-best") ?? 0);
    return Number.isFinite(v) ? v : 0;
  });
  const [hearts, setHearts] = useState(3);
  const [grid, setGrid] = useState<Grid>(() => generateMaze(sizeForLevel(1)));
  const [player, setPlayer] = useState({ r: 0, c: 0 });
  const [phase, setPhase] = useState<Phase>("memorize");
  const [memRemaining, setMemRemaining] = useState(memorizeTimeForLevel(1));
  const [elapsedSec, setElapsedSec] = useState(0);
  const [peeksLeft, setPeeksLeft] = useState(2);
  const [hintsLeft, setHintsLeft] = useState(1);
  const [isPeeking, setIsPeeking] = useState(false);
  const [wrongFlash, setWrongFlash] = useState(false);
  const [hintDir, setHintDir] = useState<Dir | null>(null);
  const [shake, setShake] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [levelGain, setLevelGain] = useState(0);

  const size = grid.length;
  const goal = { r: size - 1, c: size - 1 };
  const toastTimer = useRef<number | null>(null);

  const resetToLevel = useCallback((lvl: number, fullReset = false) => {
    const newSize = sizeForLevel(lvl);
    const loop = lvl > 6 ? 0.04 : 0;
    setGrid(generateMaze(newSize, loop));
    setPlayer({ r: 0, c: 0 });
    setLevel(lvl);
    if (fullReset) {
      setScore(0);
      setHearts(3);
    }
    setPeeksLeft(2);
    setHintsLeft(Math.max(1, 3 - Math.floor(lvl / 4)));
    setMemRemaining(memorizeTimeForLevel(lvl));
    setElapsedSec(0);
    setPhase("memorize");
    setHintDir(null);
    setIsPeeking(false);
    setWrongFlash(false);
  }, []);

  const startGame = () => {
    resetToLevel(1, true);
    setStarted(true);
  };

  // Memorize phase countdown
  useEffect(() => {
    if (phase !== "memorize") return;
    if (memRemaining <= 0) {
      setPhase("play");
      return;
    }
    const t = setTimeout(() => setMemRemaining((m) => Math.max(0, m - 100)), 100);
    return () => clearTimeout(t);
  }, [phase, memRemaining]);

  // Play phase timer
  useEffect(() => {
    if (phase !== "play") return;
    const t = setInterval(() => setElapsedSec((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [phase]);

  const showToast = (msg: string) => {
    setToast(msg);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 1500);
  };

  const completeLevel = useCallback(
    (currentHearts: number, currentElapsed: number) => {
      const gain = 80 * level + currentHearts * 25 + Math.max(0, 45 - currentElapsed) * 2;
      setLevelGain(gain);
      setScore((s) => {
        const ns = s + gain;
        setBest((b) => {
          const nb = Math.max(b, ns);
          localStorage.setItem("maze-best", String(nb));
          return nb;
        });
        return ns;
      });
      setPhase("won");
    },
    [level],
  );

  const handleWrongMove = useCallback(() => {
    setShake(true);
    setWrongFlash(true);
    showToast("Devorga urildingiz! −1 ❤️");
    window.setTimeout(() => setShake(false), 450);
    window.setTimeout(() => setWrongFlash(false), 550);
    setHearts((h) => {
      const nh = h - 1;
      if (nh <= 0) {
        window.setTimeout(() => setPhase("lost"), 550);
        return 0;
      }
      return nh;
    });
  }, []);

  const attemptMove = useCallback(
    (dir: Dir) => {
      if (phase !== "play") return;
      const { r, c } = player;
      if (!grid[r] || !grid[r][c]) return;
      if (canMove(grid, r, c, dir)) {
        const [nr, nc] = stepTo(r, c, dir);
        setPlayer({ r: nr, c: nc });
        if (nr === size - 1 && nc === size - 1) {
          setHearts((h) => {
            completeLevel(h, elapsedSec);
            return h;
          });
        }
      } else {
        handleWrongMove();
      }
    },
    [phase, grid, player, size, elapsedSec, completeLevel, handleWrongMove],
  );

  // Keyboard controls
  useEffect(() => {
    const map: Record<string, Dir> = {
      ArrowUp: "top",
      ArrowDown: "bottom",
      ArrowLeft: "left",
      ArrowRight: "right",
      w: "top",
      s: "bottom",
      a: "left",
      d: "right",
    };
    const handler = (e: KeyboardEvent) => {
      const dir = map[e.key];
      if (dir) {
        e.preventDefault();
        attemptMove(dir);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [attemptMove]);

  const handlePeek = () => {
    if (phase !== "play" || peeksLeft <= 0 || isPeeking) return;
    setPeeksLeft((p) => p - 1);
    setIsPeeking(true);
    showToast("Devorlarni eslab qoling!");
    window.setTimeout(() => setIsPeeking(false), 1200);
  };

  const handleHintBtn = () => {
    if (phase !== "play" || hintsLeft <= 0) return;
    const dir = nextHintDirection(grid, player, goal);
    if (dir) {
      setHintsLeft((h) => h - 1);
      setHintDir(dir);
      window.setTimeout(() => setHintDir(null), 1500);
    }
  };

  const goNextLevel = () => {
    setHearts((h) => Math.min(3, h + 1));
    resetToLevel(level + 1);
  };

  const restart = () => resetToLevel(1, true);

  const showWalls = phase === "memorize" || isPeeking || wrongFlash;
  const memSeconds = Math.ceil(memRemaining / 1000);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#0a0614] flex items-center justify-center p-4 font-sans">
      {/* Background ambience */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="animate-float-blob absolute -top-20 -left-20 h-72 w-72 rounded-full bg-fuchsia-700/30 blur-3xl" />
        <div
          className="animate-float-blob absolute top-1/3 -right-24 h-80 w-80 rounded-full bg-violet-700/30 blur-3xl"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="animate-float-blob absolute bottom-0 left-1/4 h-64 w-64 rounded-full bg-indigo-700/20 blur-3xl"
          style={{ animationDelay: "4s" }}
        />
      </div>

      {/* Phone frame */}
      <div className="relative z-10 w-full max-w-[380px] rounded-[2.75rem] border-[10px] border-zinc-900 bg-gradient-to-b from-[#1b1030] to-[#0b0616] p-3 shadow-[0_0_60px_rgba(168,85,247,0.25)]">
        <div className="mx-auto mb-2 h-1.5 w-20 rounded-full bg-zinc-700/70" />

        <div className="relative flex flex-col overflow-hidden rounded-[1.75rem] bg-gradient-to-b from-[#160c28] to-[#0c0718] px-3.5 pb-4 pt-3 min-h-[700px]">
          {/* Header */}
          <div className="flex items-center justify-between text-white">
            <button
              onClick={() => setShowMenu(true)}
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5 text-zinc-300 transition hover:bg-white/10 active:scale-95"
              aria-label="Menu"
            >
              <Menu size={18} />
            </button>

            <div className="flex flex-col items-center">
              <span className="text-[9px] font-semibold uppercase tracking-wider text-violet-300/70">
                Daraja
              </span>
              <span className="text-base font-bold text-violet-300">{level}</span>
            </div>

            <div className="flex items-center gap-0.5">
              {[0, 1, 2].map((i) => (
                <Heart
                  key={i}
                  size={17}
                  className={
                    i < hearts
                      ? "fill-rose-500 text-rose-500"
                      : "fill-transparent text-zinc-600"
                  }
                />
              ))}
            </div>

            <div className="flex flex-col items-center">
              <span className="text-[9px] font-semibold uppercase tracking-wider text-sky-300/70">
                Vaqt
              </span>
              <span className="flex items-center gap-0.5 text-sm font-bold text-sky-300">
                <Timer size={11} />
                {formatTime(elapsedSec)}
              </span>
            </div>

            <div className="flex flex-col items-center">
              <span className="text-[9px] font-semibold uppercase tracking-wider text-amber-300/70">
                Ball
              </span>
              <span className="text-base font-bold text-amber-300">{score}</span>
            </div>
          </div>

          {/* Status bar */}
          <div className="mt-3 flex items-center justify-between rounded-xl bg-black/40 px-3.5 py-2">
            {phase === "memorize" ? (
              <>
                <span className="flex items-center gap-1.5 text-xs font-medium text-amber-300">
                  <Eye size={14} /> Yodlab oling!
                </span>
                <span className="text-sm font-bold text-amber-300">{memSeconds}s</span>
              </>
            ) : isPeeking ? (
              <>
                <span className="flex items-center gap-1.5 text-xs font-medium text-sky-300">
                  <Eye size={14} /> Devorlarni ko'ring...
                </span>
              </>
            ) : phase === "play" ? (
              <>
                <span className="flex items-center gap-1.5 text-xs font-medium text-fuchsia-300">
                  <Sparkles size={14} /> Yo'lni xotirangizdan toping!
                </span>
                <span className="text-[11px] font-semibold text-zinc-400">
                  👁️ {peeksLeft} · 💡 {hintsLeft}
                </span>
              </>
            ) : (
              <span className="text-xs font-medium text-zinc-400">Tayyorlanmoqda...</span>
            )}
          </div>

          {/* Maze */}
          <div className="mt-3 flex flex-1 items-center justify-center">
            <div
              className={`relative aspect-square w-full max-w-[300px] rounded-2xl border border-fuchsia-500/30 bg-black/30 p-1.5 shadow-inner ${
                shake ? "animate-shake" : ""
              }`}
            >
              <div
                className="relative h-full w-full overflow-hidden rounded-xl"
                style={{
                  display: "grid",
                  gridTemplateColumns: `repeat(${size}, 1fr)`,
                  gridTemplateRows: `repeat(${size}, 1fr)`,
                }}
              >
                {grid.map((row, r) =>
                  row.map((cell, c) => {
                    const dark = (r + c) % 2 === 0;
                    return (
                      <div
                        key={`${r}-${c}`}
                        className={dark ? "bg-white/[0.02]" : "bg-white/[0.045]"}
                        style={{
                          borderTopWidth: 2.5,
                          borderRightWidth: 2.5,
                          borderBottomWidth: 2.5,
                          borderLeftWidth: 2.5,
                          borderTopColor: cell.top && showWalls ? "#d946ef" : "transparent",
                          borderRightColor: cell.right && showWalls ? "#d946ef" : "transparent",
                          borderBottomColor: cell.bottom && showWalls ? "#d946ef" : "transparent",
                          borderLeftColor: cell.left && showWalls ? "#d946ef" : "transparent",
                          transition: "border-color 300ms ease",
                        }}
                      />
                    );
                  }),
                )}

                {/* Goal flag */}
                <div
                  className="pointer-events-none absolute flex items-center justify-center transition-all duration-200"
                  style={{
                    width: `${100 / size}%`,
                    height: `${100 / size}%`,
                    left: `${(goal.c / size) * 100}%`,
                    top: `${(goal.r / size) * 100}%`,
                  }}
                >
                  <div className="flex h-[60%] w-[60%] items-center justify-center rounded-lg bg-gradient-to-br from-emerald-400/20 to-emerald-600/20">
                    <Flag size={16} className="fill-amber-300 text-amber-300" />
                  </div>
                </div>

                {/* Player */}
                <div
                  className="pointer-events-none absolute flex items-center justify-center transition-all duration-200 ease-out"
                  style={{
                    width: `${100 / size}%`,
                    height: `${100 / size}%`,
                    left: `${(player.c / size) * 100}%`,
                    top: `${(player.r / size) * 100}%`,
                  }}
                >
                  <div className="h-[62%] w-[62%] rounded-full bg-gradient-to-br from-pink-400 to-fuchsia-600 shadow-[0_0_14px_rgba(217,70,239,0.8)] ring-2 ring-white/40" />
                </div>
              </div>
            </div>
          </div>

          {/* Toast */}
          <div className="pointer-events-none flex h-6 items-center justify-center">
            {toast && (
              <span className="animate-pop-in rounded-full bg-rose-500/20 px-3 py-0.5 text-[11px] font-medium text-rose-300">
                {toast}
              </span>
            )}
          </div>

          {/* Controls */}
          <div className="mt-1 flex flex-col items-center gap-2">
            <CtrlBtn
              icon={<ArrowUp size={20} />}
              onClick={() => attemptMove("top")}
              glow={hintDir === "top"}
            />
            <div className="flex items-center gap-2">
              <CtrlBtn
                icon={<ArrowLeft size={20} />}
                onClick={() => attemptMove("left")}
                glow={hintDir === "left"}
              />
              <button
                onClick={handlePeek}
                disabled={phase !== "play" || peeksLeft <= 0}
                className={`relative flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-orange-400 to-pink-600 text-white shadow-lg transition active:scale-95 disabled:cursor-not-allowed disabled:opacity-30 ${
                  peeksLeft > 0 && phase === "play" ? "animate-pulse-ring" : ""
                }`}
                aria-label="Peek"
              >
                <Eye size={18} />
                <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-zinc-900 text-[9px] font-bold text-white ring-1 ring-orange-400/60">
                  {peeksLeft}
                </span>
              </button>
              <CtrlBtn
                icon={<ArrowRight size={20} />}
                onClick={() => attemptMove("right")}
                glow={hintDir === "right"}
              />
            </div>
            <CtrlBtn
              icon={<ArrowDown size={20} />}
              onClick={() => attemptMove("bottom")}
              glow={hintDir === "bottom"}
            />

            <button
              onClick={handleHintBtn}
              disabled={phase !== "play" || hintsLeft <= 0}
              className="mt-1 flex items-center gap-1.5 rounded-full bg-white/5 px-4 py-1.5 text-xs font-semibold text-yellow-300 transition hover:bg-white/10 active:scale-95 disabled:cursor-not-allowed disabled:opacity-30"
            >
              <Lightbulb size={14} /> Maslahat ({hintsLeft})
            </button>
          </div>

          {/* Start overlay */}
          {!started && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-5 rounded-[1.75rem] bg-[#0b0616]/97 px-6 text-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-fuchsia-500 to-violet-700 shadow-[0_0_30px_rgba(217,70,239,0.5)]">
                <span className="text-4xl">🧩</span>
              </div>
              <div>
                <h1 className="text-2xl font-extrabold text-white">Xotira Labirinti</h1>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                  Labirint devorlarini yodlab oling, so'ngra ular yo'qoladi!
                  Xotirangizga tayanib chiqish yo'lini toping va yuqori ball
                  to'plang.
                </p>
              </div>
              <div className="w-full space-y-2 rounded-2xl bg-white/5 p-3 text-left text-xs text-zinc-300">
                <p>👀 Avval yo'lni diqqat bilan yodlab oling</p>
                <p>🕹️ Strelkalar yordamida 🏁 belgisiga yeting</p>
                <p>❤️ Devorga urilsangiz jon kamayadi</p>
                <p>💡 Qiyin bo'lsa ko'rish/maslahatdan foydalaning</p>
              </div>
              <button
                onClick={startGame}
                className="w-full rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-600 py-3 text-sm font-bold text-white shadow-lg shadow-fuchsia-900/40 transition active:scale-95"
              >
                Boshlash
              </button>
              {best > 0 && (
                <p className="flex items-center gap-1 text-xs text-amber-300">
                  <Trophy size={13} /> Rekord: {best}
                </p>
              )}
            </div>
          )}

          {/* Won overlay */}
          {started && phase === "won" && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 rounded-[1.75rem] bg-[#0b0616]/97 px-6 text-center animate-pop-in">
              <span className="text-5xl">🎉</span>
              <h2 className="text-xl font-extrabold text-white">
                {level}-daraja yakunlandi!
              </h2>
              <p className="text-sm text-zinc-400">
                Siz +{levelGain} ball to'pladingiz
              </p>
              <div className="flex items-center gap-2 text-amber-300">
                <Trophy size={16} />
                <span className="font-bold">{score} ball</span>
              </div>
              <button
                onClick={goNextLevel}
                className="w-full rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-600 py-3 text-sm font-bold text-white shadow-lg transition active:scale-95"
              >
                Keyingi daraja →
              </button>
            </div>
          )}

          {/* Lost overlay */}
          {started && phase === "lost" && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 rounded-[1.75rem] bg-[#0b0616]/97 px-6 text-center animate-pop-in">
              <span className="text-5xl">💔</span>
              <h2 className="text-xl font-extrabold text-white">O'yin tugadi</h2>
              <p className="text-sm text-zinc-400">
                Siz {level}-darajaga yetdingiz
              </p>
              <div className="flex items-center gap-2 text-amber-300">
                <Trophy size={16} />
                <span className="font-bold">Jami: {score} ball</span>
              </div>
              {score >= best && score > 0 && (
                <p className="text-xs font-semibold text-fuchsia-300">
                  ✨ Yangi rekord!
                </p>
              )}
              <button
                onClick={restart}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-600 py-3 text-sm font-bold text-white shadow-lg transition active:scale-95"
              >
                <RotateCcw size={16} /> Qayta boshlash
              </button>
            </div>
          )}

          {/* Menu overlay */}
          {showMenu && (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 px-6">
              <div className="animate-pop-in w-full rounded-2xl bg-[#17102a] p-5 shadow-2xl ring-1 ring-white/10">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">Qoidalar</h3>
                  <button
                    onClick={() => setShowMenu(false)}
                    className="text-zinc-400 hover:text-white"
                  >
                    <X size={18} />
                  </button>
                </div>
                <ul className="space-y-2 text-xs leading-relaxed text-zinc-300">
                  <li>👀 Har bosqich boshida labirintni yodlab oling</li>
                  <li>🕹️ Strelkalar yoki klaviatura orqali harakatlaning</li>
                  <li>🏁 Bayroqqa yetib boring — daraja oshadi</li>
                  <li>❤️ 3 ta jon bor, devorga urilsangiz kamayadi</li>
                  <li>👁️ Peek — devorlarni qisqa muddat ko'rsatadi</li>
                  <li>💡 Maslahat — keyingi to'g'ri yo'nalishni ko'rsatadi</li>
                </ul>
                <button
                  onClick={() => setShowMenu(false)}
                  className="mt-4 w-full rounded-xl bg-fuchsia-600 py-2 text-sm font-semibold text-white active:scale-95"
                >
                  Tushunarli
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CtrlBtn({
  icon,
  onClick,
  glow,
}: {
  icon: React.ReactNode;
  onClick: () => void;
  glow?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex h-12 w-12 items-center justify-center rounded-xl text-zinc-200 transition active:scale-90 ${
        glow
          ? "bg-yellow-400/20 ring-2 ring-yellow-400 text-yellow-300"
          : "bg-white/5 hover:bg-white/10"
      }`}
    >
      {icon}
    </button>
  );
}
